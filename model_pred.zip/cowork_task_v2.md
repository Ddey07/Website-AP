# Task: Wire ML-derived team strength into the WC 2026 bracket simulator

## Goal

Replace the current Elo-only match simulator with a model-adjusted strength version. **Do not double-count** host advantage. **Do not change** the look/feel, bracket logic, slot assignment, or UI components. Also: swap the "FIFA World Rankings" tab so it displays the actual FIFA ranking (not the eloratings.net values currently misrepresented as FIFA).

All changes are in a single file: `index.html`.

---

## Background (what this is doing, conceptually)

The current `wp(a, b)` function is the classic Elo formula:

```
wp(a, b) = 1 / (1 + 10^((e(b) - e(a)) / 400))
```

It reads team Elo from the `ELO` constant. Two problems:

1. The `ELO` numbers are pure eloratings.net values; they don't reflect recent form, distance from peak, or the host bonus our ML model learned from 6 World Cups (2002–2022).
2. There's no per-match home advantage at all.

The fix:

1. **Replace what `e()` looks up.** Introduce a new constant `STRENGTH` whose values are **model-adjusted Elos** (raw Elo + form adjustments, but **excluding** any host bonus — host is handled by `h`).
2. **Add per-match home advantage.** Update `wp()` to accept a venue and apply `h = -100` when the venue's country matches a team's home country.
3. **Keep `ELO` around** because it's already used by other parts of the page (match labels, "Elite clash" / "Upset alert" classification, etc.). Don't touch those usages.
4. **Replace the Rankings tab** to use real FIFA rankings, sorted ascending by `rank`, displaying rank number + FIFA points.

---

## Step 1 — Add three new constants near the existing `ELO` constant

Find the line where the `ELO` constant is defined (somewhere near the top of the `<script>` block, before `function e(t){...}`).

**Immediately after the existing `ELO = { ... }` block**, add the three constants below.

```javascript
// =================================================================
// MODEL-ADJUSTED TEAM STRENGTH (used by wp() in match simulation)
// Includes recent form (win%, EWMA-weighted slope, peak distance) BUT NOT host bonus.
// Host advantage is applied per-match via h in the wp() formula.
// Derived from a linear regression on 192 team-tournament observations
// across the 2002–2022 World Cups (1-year window before each WC).
// Slope uses an exponentially-weighted moving average of 3/6/9/12-month sub-window
// slopes (weights 0.4 / 0.3 / 0.2 / 0.1) so recent form matters more than old form.
// =================================================================
const STRENGTH = {
  "Spain": 2262, "Argentina": 2238, "France": 2178, "England": 2119,
  "Portugal": 2098, "Colombia": 2041, "Senegal": 2029, "Germany": 2027,
  "Brazil": 2019, "Croatia": 2017, "Netherlands": 2000, "Turkey": 1975,
  "Norway": 1970, "Japan": 1968, "Austria": 1929, "Morocco": 1924,
  "Switzerland": 1909, "Belgium": 1902, "Uruguay": 1892, "Ecuador": 1874,
  "Mexico": 1869, "Algeria": 1857, "Australia": 1845, "Paraguay": 1825,
  "South Korea": 1810, "Scotland": 1807, "Iran": 1801, "Canada": 1798,
  "Panama": 1790, "United States": 1784, "Ivory Coast": 1771,
  "Uzbekistan": 1756, "Czechia": 1756, "Sweden": 1737, "DR Congo": 1728,
  "Egypt": 1725, "Jordan": 1709, "Tunisia": 1677, "Iraq": 1672,
  "Saudi Arabia": 1593, "Bosnia and Herzegovina": 1582, "South Africa": 1578,
  "Cape Verde": 1538, "New Zealand": 1509, "Haiti": 1499, "Ghana": 1488,
  "Curacao": 1429, "Qatar": 1416,
};

// =================================================================
// FIFA WORLD RANKINGS (April 2026 release) — for the Rankings tab display only
// =================================================================
const FIFA_RANK = {
  "France": {rank: 1, points: 1877.3},
  "Spain": {rank: 2, points: 1876.4},
  "Argentina": {rank: 3, points: 1874.8},
  "England": {rank: 4, points: 1826.0},
  "Portugal": {rank: 5, points: 1763.8},
  "Brazil": {rank: 6, points: 1761.2},
  "Netherlands": {rank: 7, points: 1757.9},
  "Morocco": {rank: 8, points: 1755.9},
  "Belgium": {rank: 9, points: 1734.7},
  "Germany": {rank: 10, points: 1730.4},
  "Croatia": {rank: 11, points: 1717.1},
  "Colombia": {rank: 13, points: 1693.1},
  "Senegal": {rank: 14, points: 1689.0},
  "Mexico": {rank: 15, points: 1681.0},
  "United States": {rank: 16, points: 1673.1},
  "Uruguay": {rank: 17, points: 1673.1},
  "Japan": {rank: 18, points: 1660.4},
  "Switzerland": {rank: 19, points: 1649.4},
  "Iran": {rank: 21, points: 1615.3},
  "Turkey": {rank: 22, points: 1599.0},
  "Ecuador": {rank: 23, points: 1594.8},
  "Austria": {rank: 24, points: 1593.5},
  "South Korea": {rank: 25, points: 1588.7},
  "Australia": {rank: 27, points: 1580.7},
  "Algeria": {rank: 28, points: 1564.3},
  "Egypt": {rank: 29, points: 1563.2},
  "Canada": {rank: 30, points: 1556.5},
  "Norway": {rank: 31, points: 1550.9},
  "Panama": {rank: 33, points: 1540.6},
  "Ivory Coast": {rank: 34, points: 1533.0},
  "Sweden": {rank: 38, points: 1514.8},
  "Paraguay": {rank: 40, points: 1503.5},
  "Czechia": {rank: 41, points: 1501.4},
  "Scotland": {rank: 43, points: 1498.3},
  "Tunisia": {rank: 44, points: 1483.0},
  "DR Congo": {rank: 46, points: 1478.3},
  "Uzbekistan": {rank: 50, points: 1465.3},
  "Qatar": {rank: 55, points: 1455.0},
  "Iraq": {rank: 57, points: 1447.1},
  "South Africa": {rank: 60, points: 1429.7},
  "Saudi Arabia": {rank: 61, points: 1421.4},
  "Jordan": {rank: 63, points: 1391.5},
  "Bosnia and Herzegovina": {rank: 65, points: 1385.8},
  "Cape Verde": {rank: 69, points: 1366.1},
  "Ghana": {rank: 74, points: 1346.3},
  "Curacao": {rank: 82, points: 1294.7},
  "Haiti": {rank: 83, points: 1291.7},
  "New Zealand": {rank: 85, points: 1281.6},
};

// =================================================================
// HOST COUNTRIES — used to identify when home advantage applies per match
// =================================================================
const HOME_COUNTRY = {
  "United States": "USA",
  "Canada": "Canada",
  "Mexico": "Mexico",
};
```

---

## Step 2 — Add a venue → country helper

Add this small helper function near the existing `venueType()` function (which is currently around line ~625 and returns `"texas"`/`"canada"`/`"mexico"`/`"usa"`). The new function returns the host country code that the new `wp()` will compare against `HOME_COUNTRY`.

```javascript
// Map a venue name (e.g. "Mexico City, MX", "Toronto, ON") to a host country code
// matching HOME_COUNTRY values. Returns null if not in a host country.
function venueCountry(venueName) {
  if (!venueName) return null;
  const v = String(venueName);
  if (v.includes("Toronto") || v.includes("Vancouver")) return "Canada";
  if (v.includes("Mexico City") || v.includes("Guadalajara") || v.includes("Monterrey")) return "Mexico";
  // Everything else in the venue list (LA, NJ/MetLife, Atlanta, Boston, etc.) is in the USA
  return "USA";
}
```

---

## Step 3 — Update `e(t)` and `wp(a, b)`

**Find the two existing lines** (currently around line 669–670):

```javascript
function e(t){return ELO[t]||1700;}
function wp(a,b){return 1/(1+Math.pow(10,(e(b)-e(a))/400));}
```

**Replace them with:**

```javascript
// e(t) now returns model-adjusted strength, NOT raw Elo.
// Raw Elo is still available via ELO[t] for any display logic that needs it.
function e(t){return STRENGTH[t]||ELO[t]||1700;}

// Match win probability with venue-based home advantage.
// h = -100 if A is home at this venue, +100 if B is home, 0 otherwise.
// Called with venue when available; falls back to neutral if venue is null/omitted.
function wp(a,b,venue){
  let h = 0;
  const vc = venueCountry(venue);
  if (vc) {
    if (vc === HOME_COUNTRY[a]) h -= 100;
    if (vc === HOME_COUNTRY[b]) h += 100;
  }
  return 1/(1+Math.pow(10,(e(b)-e(a)+h)/400));
}
```

**Also find** (currently right after the wp definition):

```javascript
function simMatch(a,b){return Math.random()<wp(a,b)?a:b;}
```

**Replace with:**

```javascript
function simMatch(a,b,venue){return Math.random()<wp(a,b,venue)?a:b;}
```

The new signatures are **backward-compatible** — anywhere `wp(a,b)` or `simMatch(a,b)` is called without a venue, the function treats it as neutral (h = 0). So existing callers that don't yet pass venues won't break.

---

## Step 4 — Update `simGroup` to apply host advantage in host group matches

Find the existing `simGroup` function (around line 702). It iterates pairs of teams within a group and calls `wp(a,b)*0.75`.

**Replace it with:**

```javascript
function simGroup(teams){
  const pts={},gd={};
  teams.forEach(t=>{pts[t]=0;gd[t]=0;});

  // If a host team is in this group, ALL their matches are at home in their country.
  // For host advantage, we synthesize a "venue" string just for the wp() call.
  // (Group venues in 2026 are concentrated by country, so this is accurate.)
  const hostInGroup = teams.find(t => HOME_COUNTRY[t]);
  const groupVenue = hostInGroup
    ? (HOME_COUNTRY[hostInGroup] === "USA" ? "Los Angeles" :
       HOME_COUNTRY[hostInGroup] === "Canada" ? "Toronto" :
       "Mexico City")
    : null;

  for(let i=0;i<teams.length;i++){
    for(let j=i+1;j<teams.length;j++){
      const a=teams[i],b=teams[j];
      const pA=wp(a,b,groupVenue)*0.75,r=Math.random();
      if(r<pA){pts[a]+=3;gd[a]+=(1+Math.random());gd[b]-=Math.random();}
      else if(r<pA+0.25){pts[a]+=1;pts[b]+=1;}
      else{pts[b]+=3;gd[b]+=(1+Math.random());gd[a]-=Math.random();}
    }
  }
  return [...teams].sort((a,b)=>pts[b]-pts[a]||gd[b]-gd[a]||Math.random()-.5);
}
```

Result: in Group A (Mexico), Group B (Canada), Group D (USA), the host gets `h = -100` in all 3 of their group matches. Non-host group matches in those groups also happen at host-country venues, but since neither team is from the host country, `h = 0` for those matches.

---

## Step 5 — Update `runOnce` knockouts to pass slot venues

Find the existing `runOnce()` function (around line 734). It contains four blocks like:

```javascript
const r32w=r32p.map(([a,b],idx)=>{
  if(!ok(a,b))return a&&a!=="TBD"?a:b&&b!=="TBD"?b:"TBD";
  out.r32.push({idx,key:key(a,b),teamA:a,teamB:b});
  return simMatch(a,b);
});
```

**For each of the four knockout rounds (r32, r16, qf, sf), and the final block,** update the `simMatch` call to pass the slot's venue.

The slot venue lives in the file's `KO` data structure (or wherever the bracket slot list is stored — visible in the SlotCard component: `slot.venue`). The implementer needs to thread that venue through.

Concrete pattern (do this for r32, r16, qf, sf, and final):

```javascript
const r32w=r32p.map(([a,b],idx)=>{
  if(!ok(a,b))return a&&a!=="TBD"?a:b&&b!=="TBD"?b:"TBD";
  out.r32.push({idx,key:key(a,b),teamA:a,teamB:b});
  const venue = KO.r32?.[idx]?.venue;     // <-- pull from slot data
  return simMatch(a,b,venue);              // <-- pass to simMatch
});
```

Apply the same change to `r16w`, `qfw`, `sfw`, and the final block:

```javascript
let champion="TBD";
if(ok(sfw[0],sfw[1])){
  out.final.push({idx:0,key:key(sfw[0],sfw[1]),teamA:sfw[0],teamB:sfw[1]});
  const venue = KO.final?.[0]?.venue;
  champion=simMatch(sfw[0],sfw[1],venue);
}
else champion=sfw[0]!=="TBD"?sfw[0]:sfw[1];
```

If `KO` slots are exposed under a different name in the existing file, substitute that. The key is: every `simMatch(a,b)` inside `runOnce` becomes `simMatch(a,b,venue)` where `venue` is pulled from the slot definition for that round/index.

If the slot data isn't reachable from `runOnce`'s scope, the simplest patch is to:
- Build a `VENUE_MAP = {r32: [...16 venue strings...], r16: [...8...], qf: [...4...], sf: [...2...], final: [...1...]}` near the top of the file, keyed off the existing slot definitions.
- Reference `VENUE_MAP.r32[idx]` etc. inside `runOnce`.

---

## Step 6 — Replace the Rankings tab to show actual FIFA rankings

Find the existing Rankings tab (around line 3486, starts with `{tab==="rankings"&&(`). It currently iterates `SORTED_ELO` and labels itself "FIFA World Rankings" — but the data is eloratings.net values, not FIFA values. This is misleading and should be fixed.

**Find this near the top of the script:**

```javascript
const SORTED_ELO = Object.entries(ELO).sort(([,a],[,b])=>b-a);
```

**Add immediately after it:**

```javascript
// Teams sorted by official FIFA ranking (ascending — rank 1 first)
const SORTED_BY_FIFA = Object.entries(FIFA_RANK)
  .sort(([,a],[,b]) => a.rank - b.rank);
const MAX_FIFA_POINTS = Math.max(...Object.values(FIFA_RANK).map(x => x.points));
```

**Then find the Rankings tab JSX:**

```jsx
{tab==="rankings"&&(
  <div>
    <h2 ...>📊 FIFA World Rankings</h2>
    <p ...>All 48 qualified teams ranked by ELO rating with recent form indicator</p>
    <div ...>
      {SORTED_ELO.map(([t,elo],i)=>{
        const f=FORM[t]||0;
        const maxElo=SORTED_ELO[0][1];
        const barW=(elo/maxElo)*100;
        ...
        <span>{elo}</span>
      })}
    </div>
  </div>
)}
```

**Replace the inner content** so it iterates `SORTED_BY_FIFA` and displays FIFA rank + FIFA points:

```jsx
{tab==="rankings"&&(
  <div>
    <h2 style={{fontSize:18,fontWeight:700,color:"#f1f5f9",marginBottom:4}}>📊 FIFA World Rankings</h2>
    <p style={{color:"#64748b",fontSize:13,marginBottom:20}}>All 48 qualified teams ranked by official FIFA ranking (April 2026)</p>
    <div style={{display:"grid",gap:5}}>
      {SORTED_BY_FIFA.map(([t, info], i) => {
        const f = FORM[t] || 0;
        const barW = (info.points / MAX_FIFA_POINTS) * 100;
        const teamColor = COLORS[t] || "#334155";
        return (
          <div key={t} style={{
            background:"#061228", border:"1px solid #1e3a5f",
            borderRadius:8, padding:"8px 12px",
            display:"flex", alignItems:"center", gap:10, flexWrap:"wrap"
          }}>
            <span style={{color:"#475569",fontSize:12,minWidth:24,textAlign:"right"}}>#{info.rank}</span>
            <span style={{fontSize:20}}>{fl(t)}</span>
            <div style={{flex:1, minWidth:120}}>
              <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:3,flexWrap:"wrap"}}>
                <span style={{fontWeight:600,fontSize:13}}>{t}</span>
                <span style={{color:fc(f),fontSize:11,fontWeight:700,background:"#0d1f3c",padding:"1px 6px",borderRadius:10}}>{fa(f)}</span>
              </div>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <div style={{flex:1, height:6, background:"#0d1f3c", borderRadius:3, overflow:"hidden"}}>
                  <div style={{width:`${barW}%`, height:"100%", background:teamColor, borderRadius:3}}/>
                </div>
                <span style={{color:"#60a5fa",fontSize:12,fontWeight:700,minWidth:56,textAlign:"right"}}>{info.points.toFixed(1)} pts</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  </div>
)}
```

Visual changes from the original:
- The left number is now `#1`, `#2`, ... pulled from `info.rank` (the actual FIFA rank).
- The right number is `1877.3 pts` instead of an Elo number — that's the FIFA points value.
- Bar width is proportional to FIFA points (relative to leader France at 1877.3).
- Everything else (flags, form arrow, colors) stays identical.

---

## Step 7 — Do NOT change any of these

Leave the following alone — they're already correct and changing them risks breaking other parts of the UI:

- The `ELO` constant — it's still used by `matchLabel()` (line ~643) for "Elite clash" / "Upset alert" / "Mismatch" classification. Those labels should keep using raw eloratings.net values.
- All `GROUPS`, `SLOT_ALLOW_C`, `THIRD_SLOT_ORD`, and `KO` data structures.
- The 12-group structure and slot-assignment backtracking logic (`assignUserThirds`, `assign3rd`, `buildUserR32`).
- The Monte Carlo loop count (`N`) and aggregation logic.
- The `GroupCard`, `SlotCard`, `BracketTreeSVG` components and styling.
- The map, trip-planner, bracket-challenge tabs.
- The Supabase wiring and bracket-lock logic.
- Footer text.

---

## Step 8 — Verification

After changes, the page should:

1. **Rankings tab**: shows France #1, Spain #2, Argentina #3, England #4, Portugal #5, Brazil #6 — with "1877.3 pts" type values, not Elo numbers in the 1800–2000 range.
2. **Group stage tab**: should still render all 12 groups identically. Mexico, USA, Canada qualification probabilities should be slightly higher than before (due to per-match home advantage in their groups).
3. **Knockout tabs (R32/R16/QF/SF/Final)**: top picks should be roughly Spain, Argentina, France in some order — they have the highest `STRENGTH` (2262 / 2238 / 2178). Note: USA may appear with elevated advancement probabilities specifically in late KO rounds played at MetLife (because that's a USA home venue) but should not be unduly inflated in Mexico/Canada-hosted matches.
4. **Console**: no errors. The `simMatch(a, b)` calls without a venue argument (if any remain in the file outside `runOnce`/`simGroup`) still work because the venue parameter is optional.
5. **No double-counting check**: a host should advance further than their `STRENGTH` alone would suggest (because of `h = -100` per home match), but not absurdly. Hosts should reach the round of 16 maybe 60–70% of the time, not 95%+. If hosts are dominating the simulation, something is wrong.

---

## Why these specific values

- **STRENGTH values** come from a linear regression trained on 192 team-tournament observations from the 2002–2022 World Cups (6 tournaments × 32 teams). The model uses 5 features computed from each team's match history in the 1 year prior to the WC: pre-WC Elo, win percentage, EWMA-weighted slope of Elo trajectory, distance from recent peak, and host status. The slope feature uses a weighted blend of 3/6/9/12-month sub-window slopes (weights 0.4 / 0.3 / 0.2 / 0.1) so recent form matters more than older form — this was a deliberate refinement over a naive full-window slope, which had a counterintuitive negative coefficient due to multicollinearity. The smoothed version has a positive coefficient (~+170 Elo per Elo/day of trend) that matches intuition: improving teams get rewarded. Cross-validation on the 6 historical WCs gave MAE ≈ 0.83 rounds, Spearman ρ ≈ 0.54, QWK ≈ +0.36.
- **`h = 100`** is the standard per-match home advantage used by eloratings.net and supported by published research on international football. It produces roughly a 64% expected score against an equal opponent at home.
- **The `is_host` coefficient is deliberately EXCLUDED from `STRENGTH`** because it represented the cumulative tournament effect, which the simulator now produces naturally by applying `h = -100` to each home match. Including both would double-count.

---

## If anything is ambiguous

If any line numbers in this document don't match the actual file (file may have been edited since this task was written), search for these anchors instead:

- The `ELO` constant: search for `const ELO =` or `ELO={` near the top of the `<script>` block.
- The `e(t)` function: search for `function e(t)`.
- The `wp(a,b)` function: search for `function wp(`.
- The `simMatch` function: search for `function simMatch(`.
- The `simGroup` function: search for `function simGroup(`.
- The `runOnce` function: search for `function runOnce(`.
- The Rankings tab: search for `📊 FIFA World Rankings` or `tab==="rankings"`.

Do not attempt to retrain the model or change the coefficients — those numbers are fixed deliverables. Just place them in the file and rewire the functions.
